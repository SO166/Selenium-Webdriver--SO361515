import java.io.File;
import java.io.IOException;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class ExcelParser {
	
private String filepath;
	
	private String[][] parameterArray;

	public ExcelParser(String p_filepath) {
		// TODO Auto-generated constructor stub
		this.filepath=p_filepath;
	}

	public String[][] retriveData() throws BiffException, IOException{
		
		File myExcelFile=new File(filepath);
		Workbook objWork=Workbook.getWorkbook(myExcelFile);
		Sheet Objectsheet=objWork.getSheet(0);
		int rows=Objectsheet.getRows();
		int cols=Objectsheet.getColumns();	
		
		String [][] parameterArray=new String[rows][cols];
		for(int row=0;row<rows;row++)
		{
			for(int col=0;col<cols;col++)
			{
				Cell ObjCell=Objectsheet.getCell(col,row);
				parameterArray[col][row]=ObjCell.getContents();
			}
		}
		return parameterArray;
	}

	public String[][] getParameterArray() {
		return parameterArray;
	}

	public void setParameterArray(String[][] parameterArray) {
		this.parameterArray = parameterArray;
	}

}
