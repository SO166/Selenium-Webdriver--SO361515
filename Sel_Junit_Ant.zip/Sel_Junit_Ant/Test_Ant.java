import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import jxl.read.biff.BiffException;


public class Test_Ant  {
	
/*@SuppressWarnings("unused")
public static void main(String args[]) throws BiffException, IOException 
	 {
		// TODO Auto-generated method stub
		
		ExcelParser objExcelParser=new ExcelParser("login.xls");
		String[][] myLoginData=objExcelParser.retriveData();
	}*/
	
	
		
	
	public WebDriver driver;
	
	
	@Test(priority=0)
	public  void Login() throws InterruptedException, BiffException, IOException
	{
		//System.setProperty("webdriver.firefox.marionette","");
	//System.setProperty("webdriver.chrome.driver","C:\\BrowserDrivers\\BrowserDrivers\\chromedriver.exe");
	//System.setProperty("webdriver.Gecko.driver","C:\\BrowserDrivers\\BrowserDriversgeckodriver-v0.20.1-win64\\geckodriver.exe");
		
		ExcelParser objExcelParser=new ExcelParser("login.xls");
		String[][] myLoginData=objExcelParser.retriveData();
		

		for(int iteration=0;iteration<myLoginData[0].length;iteration++)
		{
		
		
	System.setProperty("webdriver.ie.driver", "D:\\BrowserDrivers\\IEDriverServer.exe");
	
       driver = new InternetExplorerDriver();
		//WebDriver driver = new ChromeDriver();
		//WebDriver driver = new FirefoxDriver();
		
		
	// launch Fire fox and direct it to the Base URL
	 //String baseUrl = "https://www.flipkart.com/";
	 
	 driver.manage().window().maximize();
	
	driver.get("http://10.207.182.108:80/opencart/"); 
	 //driver.get("https://www.flipkart.com/");
    //String expectedTitle="Your Store";

    // get the actual value of the title
	
	  driver.findElement(By.xpath("//body/div/div[1]/div[4]/a[1]")).click();
	  driver.findElement(By.xpath("//body/div/div[5]/div[2]/div[2]/form/div/input[1]")).sendKeys(myLoginData[0][iteration]);
	  driver.findElement(By.xpath("//body/div/div[5]/div[2]/div[2]/form/div/input[2]")).sendKeys(myLoginData[1][iteration]);
	  driver.findElement(By.xpath("//body/div/div[5]/div[2]/div[2]/form/div/input[2]")).click();
   
	  driver.wait(3000);
    
    System.out.println("Hii");
   // String actualTitle = driver.getTitle();
    String strPageTitle=driver.getTitle();
    
    
    
   
    
    System.out.println(strPageTitle);
    
   // Assert.assertEquals(strPageTitle.equalsIgnoreCase("Your Store"),"Your Store");
    
    
		}
		
	}
		
    @Test(priority=1)
    public void reg_Opencart(){
    	
    driver.findElement(By.xpath("//body/div/div[1]/div[4]/a[1]")).click();
    //driver.findElement(By.xpath("//body/div/div[1]/div[4]/a[1]")).click();
    
    driver.findElement(By.xpath("//body/div/div[5]/div[2]/div[1]/div/a")).click();
    
    driver.findElement(By.xpath("//body/div[1]/div[5]/form/div[1]/table/tbody/tr[1]/td[2]/input"));
    
    driver.findElement(By.xpath("//body/div[1]/div[5]/form/div[1]/table/tbody/tr[1]/td[2]/input")).sendKeys("Ram");
    
    driver.findElement(By.xpath("//body/div[1]/div[5]/form/div[1]/table/tbody/tr[2]/td[2]/input")).sendKeys("Nath");
    
    driver.findElement(By.xpath("//body/div[1]/div[5]/form/div[1]/table/tbody/tr[3]/td[2]/input")).sendKeys("ram104@gmail.com");
    
    driver.findElement(By.xpath("//body/div[1]/div[5]/form/div[1]/table/tbody/tr[4]/td[2]/input")).sendKeys("8763336756");
    
    driver.findElement(By.xpath("//body/div[1]/div[5]/form/div[1]/table/tbody/tr[5]/td[2]/input")).sendKeys("8763");
    
    driver.findElement(By.xpath("//body/div[1]/div[5]/form/div[2]/table/tbody/tr[1]/td[2]/input")).sendKeys("Wipro");
    
    driver.findElement(By.xpath("//body/div[1]/div[5]/form/div[2]/table/tbody/tr[3]/td[2]/input")).sendKeys("SO456787");
    
    driver.findElement(By.xpath("//body/div[1]/div[5]/form/div[2]/table/tbody/tr[5]/td[2]/input")).sendKeys("Shanti Nilay");
    
    driver.findElement(By.xpath("//body/div[1]/div[5]/form/div[2]/table/tbody/tr[7]/td[2]/input")).sendKeys("Bhubaneswar");
    
    driver.findElement(By.xpath("//body/div[1]/div[5]/form/div[2]/table/tbody/tr[8]/td[2]/input")).sendKeys("657878");
    driver.findElement(By.xpath("//body/div[1]/div[5]/form/div[2]/table/tbody/tr[9]/td[2]/select")).sendKeys("India ");
    driver.findElement(By.xpath("//body/div[1]/div[5]/form/div[2]/table/tbody/tr[10]/td[2]/select")).sendKeys("Odisha");
    
    driver.findElement(By.xpath("//body/div[1]/div[5]/form/div[3]/table/tbody/tr[1]/td[2]/input")).sendKeys("Orange");
    driver.findElement(By.xpath("//body/div[1]/div[5]/form/div[3]/table/tbody/tr[2]/td[2]/input")).sendKeys("Orange");
    driver.findElement(By.xpath("//body/div[1]/div[5]/form/div[5]/div/input[1]")).click();
    driver.findElement(By.xpath("//body/div[1]/div[5]/form/div[5]/div/input[2]")).click();
   String text= driver.findElement(By.xpath("//body/div/div[5]/h1")).getText();
    String expectedText="Your Account Has Been Created!";
   System.out.println(text);
   Assert.assertEquals(text,expectedText);
  
   driver.findElement(By.xpath("//body/div/div[1]/div[4]/a[2]")).click();
    
    
   // Thread.sleep(3000);
    
   //driver.quit();
   
  //  driver.findElement(By.xpath("//html/body/div/div[4]/div[2]/div[2]/div/div[1]/div[4]/input")).click();
    
    
  
    
    
 //   driver.quit();
    }

}
	
	  
	  
	  
	 /* @afterclass(priority = 0)
	  public  void Test_Ant3() {
		  
		  
		  System.out.println("Priority is Three");  
		  
	  }  */


